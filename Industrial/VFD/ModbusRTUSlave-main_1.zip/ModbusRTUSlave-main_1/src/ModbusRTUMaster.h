#ifndef MASTER_H
#define MASTER_H

#include <Arduino.h>
#include <ModbusRTUMaster.h>

// Define slave device ID
const byte slaveID = 1;

class Master {
public:
    Master();

    // Initialize Modbus communication
    void begin();

    // Main loop for Modbus master logic
    void loop();

private:
    ModbusRTUMaster modbus;

    // Add any additional private variables or functions here
};

#endif
